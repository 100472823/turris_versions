#!/bin/sh
# Script de prueba rollback por descripción BASE_RYSCA

DESC="BASE_RYSCA"
ID=$(schnapps list | awk -v d="$DESC" '$0 ~ d {print $1}' | tail -1)

if [ -n "$ID" ]; then
  echo "✅ Encontrado snapshot con descripción \"$DESC\": ID=$ID"
  echo "Ejecutando rollback..."
  schnapps rollback "$ID"
  echo "Hecho. Reinicia para aplicar el snapshot."
else
  echo "❌ No se encontró ningún snapshot con descripción \"$DESC\""
  exit 1
fi

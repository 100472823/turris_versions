#!/bin/sh
DESC="2025-BASE1-100472823"
ID=$(/usr/bin/schnapps list | awk -v d="$DESC" '$0 ~ d {print $1}' | tail -1)
[ -z "$ID" ] && exit 0

# ruta del snapshot destino
TARGET="/@/.snapshots/${ID}/snapshot"

# snapshot actual montado en /
CUR=$(mount | awk '$3=="/"{print $6}' | sed -n 's/.*subvol=\([^,)]*\).*/\1/p')

# si ya estamos en el snapshot correcto, salir sin hacer nada
if [ "$CUR" = "$TARGET" ]; then
  exit 0
fi

# si no, hacer rollback y reiniciar
/usr/bin/schnapps rollback "$ID" && /sbin/reboot

-- Auto-generated updater-ng configuration
Repository('localrepo-auto', './auto', {index = 'Packages.gz'})

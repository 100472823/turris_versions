#!/bin/sh
cert-backup -X "$1"
